using UnityEngine;

public class ScaleModifier : MonoBehaviour
{
    public ScaleEffect scaleEffect;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            PlayerController player = other.GetComponent<PlayerController>();
            if (player != null)
            {
                // Menambah atau mengurangi skala pemain sesuai dengan efek
                player.ModifyScale(scaleEffect.scaleChangeAmount);
            }
        }
    }
}
