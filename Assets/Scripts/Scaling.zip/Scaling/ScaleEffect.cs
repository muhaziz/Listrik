using UnityEngine;

[CreateAssetMenu(fileName = "New Scale Effect", menuName = "Scale Effect")]
public class ScaleEffect : ScriptableObject
{
    public float scaleChangeAmount = 0.1f; // Jumlah perubahan skala pemain
}
