using UnityEngine;

public class Fallstate : PlayerState
{
    public Fallstate(PlayerController playerController) : base(playerController)
    {
    }

    public override void EnterState()
    {

    }

    public override void ExitState()
    {

    }

    public override void FixedUpdate()
    {

    }

    public override void Update()
    {
        if (playerController.IsGrounded())
        {
            playerController.ChangeState(new LocomotionState(playerController));
        }
    }
}