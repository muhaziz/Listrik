
// LocomotionState.cs
using UnityEngine;

public class LocomotionState : PlayerState
{
    public LocomotionState(PlayerController playerController) : base(playerController) { }

    public override void EnterState()
    {
        // Enter state logic
    }

    public override void Update()
    {
        playerController.HandleInput(); // Panggil HandleInput dari PlayerController

        if (playerController.IsGrounded())
        {
            if (playerController.IsMoving())
            {
                MovePlayer();
            }
            else
            {
                playerController.ApplyFriction();
            }

            if (playerController.HandleInput.jumpPressed())
            {
                playerController.ChangeState(new JumpingState(playerController));
            }
        }
        else
        {
            playerController.ChangeState(new Fallstate(playerController));
        }
    }

    public override void FixedUpdate()
    {
        // FixedUpdate logic
    }

    public override void ExitState()
    {
        // Exit state logic
    }

    private void MovePlayer()
    {
        playerController.rb.velocity = new Vector2(playerController.horizontalInput * playerController.speed, playerController.rb.velocity.y);
    }
}