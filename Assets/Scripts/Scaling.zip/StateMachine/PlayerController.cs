using System.Collections;
using UnityEngine;

public class PlayerController : PlayerStateMachine
{
    // Variabel untuk dash
    public float dashSpeed = 10f; // Kecepatan dash, dapat disesuaikan sesuai kebutuhan
    public bool canDash;

    // Variabel untuk input dan deteksi tanah
    public float horizontalInput; // Ubah menjadi public agar bisa diakses dari kelas lain
    public Transform groundCheckPosition;
    public LayerMask groundLayer;
    public float groundCheckRadius = 0.1f;
    private bool isGrounded;

    // Variabel untuk skala pemain
    private Vector3 originalScale;
    public bool isMoving;
    private bool isRecovering; // Flag untuk menandai apakah pemain sedang dalam proses pemulihan skala
    private float recoverySpeed = 0.1f; // Kecepatan pemulihan skala
    public float maxReduction = 0.5f; // Persentase maksimum dari ukuran asli
    public float reductionRate = 0.1f; // Tingkat penurunan ukuran setiap detik saat bergerak

    protected override void InitializeStateMachine()
    {
        currentState = new LocomotionState(this);
    }

    protected override void Update()
    {
        base.Update();
        currentState.Update();
    }

    protected override void FixedUpdate()
    {
        base.FixedUpdate();
        currentState.FixedUpdate();
    }

    protected override void Start()
    {
        base.Start();
        //originalScale = transform.localScale;
    }

    public void SetHorizontalInput(float input)
    {
        horizontalInput = input;

        // Determine if player is moving
        isMoving = Mathf.Abs(horizontalInput) > 0;
    }

    public bool IsMoving()
    {
        return isMoving;
    }

    public void Jump()
    {
        if (isGrounded)
        {
            rb.velocity = new Vector2(rb.velocity.x, jumpForce);
        }
    }

    public void ApplyFriction()
    {
        // Implement friction logic (e.g., slowing down the player when no input is given)
        // Example:
        // rb.velocity = new Vector2(rb.velocity.x * frictionFactor, rb.velocity.y);
    }

    public bool IsGrounded()
    {
        // Implement ground detection logic
        isGrounded = Physics2D.OverlapCircle(groundCheckPosition.position, groundCheckRadius, groundLayer);
        return isGrounded;
    }
    public bool IsJumping()
    {
        // Implementasi kondisi loncat (misalnya, berdasarkan tombol loncat yang ditekan)
        return Input.GetKeyDown(KeyCode.Space); // Ubah ini berdasarkan implementasi loncat Anda
    }

    public void HandleInput()
    {
        float horizontalInput = Input.GetAxis("Horizontal");
        bool jumpPressed = Input.GetKeyDown(KeyCode.Space);

        SetHorizontalInput(horizontalInput);
        if (jumpPressed)
        {
            Jump();
        }
    }
}