using UnityEngine;

public abstract class PlayerStateMachine : MonoBehaviour
{
    protected PlayerState currentState;

    public float speed = 5f;
    public float jumpForce = 5f;

    protected Rigidbody2D rb;

    protected virtual void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        InitializeStateMachine();
    }

    protected abstract void InitializeStateMachine();

    protected virtual void Update()
    {
        currentState?.Update();
    }

    protected virtual void FixedUpdate()
    {
        currentState?.FixedUpdate();
    }

    public void ChangeState(PlayerState newState)
    {
        currentState?.ExitState();
        currentState = newState;
        currentState?.EnterState();
    }
}