public abstract class PlayerState
{
    protected PlayerController playerController;

    public abstract void EnterState();
    public abstract void Update();
    public abstract void FixedUpdate();
    public abstract void ExitState();

    public PlayerState(PlayerController playerController)
    {
        this.playerController = playerController;
    }
}
