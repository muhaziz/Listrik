using UnityEngine;

public class JumpingState : PlayerState
{
    public JumpingState(PlayerController playerController) : base(playerController) { }

    public override void EnterState()
    {
        // Enter state logic
    }

    public override void Update()
    {
        // Update logic
    }

    public override void FixedUpdate()
    {
        // FixedUpdate logic
    }

    public override void ExitState()
    {
        // Exit state logic
    }
}